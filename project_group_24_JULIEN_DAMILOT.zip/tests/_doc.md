# Documentation to create rules for eslint (custom rules)

 - estree code  : https://astexplorer.net/
 - https://eslint.org/docs/latest/developer-guide/working-with-rules

 - create a file in eslint-rules with the rule (copy code from another rule)
 - enable rule by adding it to eslintrc.json 