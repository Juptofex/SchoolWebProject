module.exports = require('better-sqlite3')('data/project.db');
